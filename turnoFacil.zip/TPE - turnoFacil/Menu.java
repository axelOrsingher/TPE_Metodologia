public class Menu {
    CentroMedico cm;

    public Menu(CentroMedico cm){
        this.cm = cm;
    }

    public void iniciarSesion(long dni){
        if (cm.existePaciente(dni))
            mostrarOpciones();
    }




    public void mostrarOpciones()
}

public abstract class FiltroMedico {
    public abstract boolean cumple(Medico m);
}

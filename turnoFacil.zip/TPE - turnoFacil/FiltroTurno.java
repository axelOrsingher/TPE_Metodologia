public abstract class FiltroTurno {
    public abstract boolean cumple(Turno t);
}

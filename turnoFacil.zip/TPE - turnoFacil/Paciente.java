import java.util.ArrayList;

public class Paciente {
    private long dni;
    private String nombre;
    private String apellido;
    private String direccion;
    private long telefono;
    private String email;
    private String obraSocial;
    private int nroAfiliado;
    private ArrayList<Turno> turnos;


    public Paciente(long dni, String nombre, String apellido, String direccion, long telefono, String email,
            String obraSocial, int nroAfiliado) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.obraSocial = obraSocial;
        this.nroAfiliado = nroAfiliado;
        turnos = new ArrayList<>();
    }



    
}

import java.util.ArrayList;

public class CentroMedico { //representa la carga de datos de los usuarios, medicos y secretarias
    private String nombre;
    private ArrayList<Medico> medicos;
    private ArrayList<Secretaria> secretarias;
    private ArrayList<Paciente> pacientes;


    public CentroMedico(String nombre){
        this.nombre = nombre;
        medicos = new ArrayList<>();
        secretarias = new ArrayList<>();
        pacientes = new ArrayList<>();
    }

    public void addMedico(Medico m){
        medicos.add(m);
    }

    public void addSecretaria(Secretaria s){
        secretarias.add(s);
    }

    public void addPaciente(Paciente p){
        pacientes.add(p);
    }

    public ArrayList<Medico> getMedicos(){
        return new ArrayList<>(medicos);
    }


    public ArrayList<Medico> getMedicos(FiltroMedico f){
        ArrayList<Medico> salida = new ArrayList<>();
        for(Medico m:medicos)
            if (f.cumple(m))
                salida.add(m);
        return salida;
    }

}
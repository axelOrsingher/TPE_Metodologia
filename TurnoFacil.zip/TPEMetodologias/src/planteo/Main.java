package planteo;
import java.time.LocalTime;

public class Main {

	public static void main(String[] args) {
		Menu m = new Menu();
		
		CentroMedico cm = new CentroMedico();
		
		Paciente p = new Paciente(43872001,"Mateo","Rodon","Dorrego 1245",1234,"mateorodon123@mail.com","OSDE",1);
		Paciente p2 = new Paciente(44444444,"Axel","Rodon","Dorrego 1245",1234,"mateorodon123@mail.com","OSDE",1);
		Paciente p3 = new Paciente(43333333,"Santino","Rodon","Dorrego 1245",1234,"mateorodon123@mail.com","OSDE",1);
		
		Medico medico = new Medico("MarceloTossini", "Marcelo", "1234", "Traumatologo");



		cm.crearCuentaPaciente(43872001,"Mateo","Rodon","Dorrego 1245",1234,"mateorodon123@mail.com","OSDE",1);
		cm.crearCuentaPaciente(44444444,"Axel","Rodon","Dorrego 1245",1234,"mateorodon123@mail.com","OSDE",1);
		cm.crearCuentaPaciente(43333333,"Santino","Rodon","Dorrego 1245",1234,"mateorodon123@mail.com","OSDE",1);
		
		cm.crearCuentaSecretaria("Analia", "124");
		cm.crearCuentaSecretaria("Josefa", "111");
		
		cm.crearCuentaMedico("Lara Venere","laravenere", "123", "Traumatologa");
		cm.crearCuentaMedico("Agustina Alabart","agusalabart", "122", "Neurocirujana");
		

		m.mostrarOpciones(cm, p3);

	}

}

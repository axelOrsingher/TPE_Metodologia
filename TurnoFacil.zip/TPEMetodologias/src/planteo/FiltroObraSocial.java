package planteo;

public class FiltroObraSocial extends Filtro{
	String os;
	
	public FiltroObraSocial(String o) {
		os=o;
	}
	
	@Override
	public boolean cumple(Medico m) {
		return m.getObraSocial().contains(os);
	}

}

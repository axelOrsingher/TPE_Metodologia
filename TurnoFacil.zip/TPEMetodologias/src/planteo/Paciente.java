package planteo;

import java.util.ArrayList;
import java.util.Scanner;

public class Paciente {
    private long DNI;
    private String nombre;
    private String apellido;
    private String direccion;
    private long telefono;
    private String email;
    private String obraSocial;
    private int nroAfiliado;
    private ArrayList<Turno> turnos;

    public Paciente(long DNI,String nombre, String apellido, String direccion, 
    		long telefono, String email, String obraSocial, int nroAfiliado){
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.obraSocial = obraSocial;
        this.nroAfiliado = nroAfiliado;
        turnos = new ArrayList<>();
    }

    public long getDNI() {
    	return DNI;
    }

    public void sacarTurno (CentroMedico c) {
        Medico m = seleccionarMedico(c);
    }
    
    public void sacarTurnoFiltro(CentroMedico c,Filtro f){
        Medico m = seleccionarMedico(c, f);
        //Turno n = new Turno(m,this,)
    }
    
    private int seleccionarNroMedico(ArrayList<Medico> medicos) {
    	System.out.println("Seleccione el medico que quiera atenderse: ");
    	for (int i =0;i<medicos.size();i++) {
    		System.out.println(i + "." + medicos.get(i).getNombre());
    	}
        Scanner salida = new Scanner (System.in); 
		int pos;
		pos = salida.nextInt();
        salida.close();
        return (pos-1);
    }

    private Medico seleccionarMedico(CentroMedico c){
        ArrayList<Medico> m = c.getMedicos();
        return m.get(this.seleccionarNroMedico(m));
    }
    

    private Medico seleccionarMedico(CentroMedico c,Filtro f){
        ArrayList<Medico> m = c.getMedicosFiltro(f);
        return m.get(this.seleccionarNroMedico(m));
    }

    public ArrayList<Turno> verProxTurnos(){
    	if (!turnos.isEmpty())
    		return new ArrayList<>(turnos);
    	return null;
    }

    @Override
    public boolean equals(Object o) {
    	Paciente p = (Paciente) o;
    	return this.getDNI() == p.getDNI();
    }

	public String getNombre() {
		return nombre;
	}
	
	public boolean existeTurno(int cod) {
		for (Turno t : turnos) {
			if (t.getCodigo()==cod) {
				return true;
			}
		}
		return false;
	}
	
	public void borrarTurno (int cod) {
		for (Turno t: turnos) {
			if (t.getCodigo()==cod) {
				turnos.remove(t);
			}
		}
	}

    public String toString(){
        return "DNI = " + this.DNI + " | Nombre = " + this.nombre + " | Apellido = " + this.apellido;
    }

    public void setDNI(long dNI) {
        DNI = dNI;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public long getTelefono() {
        return telefono;
    }

    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getObraSocial() {
        return obraSocial;
    }

    public void setObraSocial(String obraSocial) {
        this.obraSocial = obraSocial;
    }

    public int getNroAfiliado() {
        return nroAfiliado;
    }

    public void setNroAfiliado(int nroAfiliado) {
        this.nroAfiliado = nroAfiliado;
    }

    

}

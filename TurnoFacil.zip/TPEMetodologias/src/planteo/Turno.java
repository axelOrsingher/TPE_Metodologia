package planteo;

import java.time.LocalTime;
import java.time.LocalDate;

public class Turno {
	private int codigo;
    private Medico medico;
    private Paciente paciente;
    private LocalTime horarioInicio;
    private LocalTime horarioFin;
    private LocalDate fecha;

    public Turno(int codigo,Medico m, Paciente p, LocalTime d, LocalTime e){
        this.codigo=codigo;
    	this.medico = m;
        this.paciente = p;
        this.horarioInicio = d;
        this.horarioFin = e;
        this.fecha = LocalDate.now();
    }

	public int getCodigo() {
		return codigo;
	}

    @Override
    public String toString(){
        return "Codigo turno = " + this.codigo + " | Medico = " + this.medico.toString() + " | Paciente = " + this.paciente.toString() + " | Horario inicio = " + this.horarioInicio + " | Horario fin = " + this.horarioFin + " | Fecha = " + this.fecha;

    }
    
}
package planteo;

import java.util.ArrayList;

public class CentroMedico{
    private ArrayList<Medico> medicos;
    private ArrayList<Secretaria> secretarias;
    private ArrayList<Paciente> pacientes;


    public CentroMedico(){
        medicos = new ArrayList<>();
        secretarias = new ArrayList<>();
        pacientes = new ArrayList<>();
    }



    public void asignarSecretaria(Secretaria s, Medico m){
        s.agregarMedico(m);
        m.setSecretaria(s);
    }
    

    public void crearCuentaMedico(String nombre, String username,String password, String especialidad){
        Medico m = new Medico(nombre, username, password, especialidad);
        this.medicos.add(m);
    }

    public void crearCuentaSecretaria(String username,String password){
        Secretaria s = new Secretaria(username,password);
        this.secretarias.add(s);
    }

    public ArrayList<Medico> getMedicos(){
        ArrayList<Medico> salida = new ArrayList<>(medicos);
        return salida;
    }

    public ArrayList<Medico> getMedicosFiltro(Filtro f){
        ArrayList<Medico> salida = new ArrayList<>();
        for (Medico m:medicos)
            if (f.cumple(m))
                salida.add(m);
        return salida;
    }
    
    public Paciente crearCuentaPaciente(long DNI,String nombre, String apellido, String direccion, long telefono, String email, String obraSocial, int nroAfiliado) {
    	Paciente p = new Paciente(DNI, nombre, apellido, direccion, telefono, email, obraSocial, nroAfiliado);
    	this.pacientes.add(p);
    	return p;
    }
    
    public boolean existePaciente(Paciente p) {
    	return pacientes.contains(p);
    }
    
    public boolean existeDNI(long dni) {
    	for(Paciente p: pacientes)
    		if (p.getDNI()== dni)
    			return true;
    	return false;
    }

}
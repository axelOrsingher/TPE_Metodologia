package planteo;

public class FiltroEspecialidad extends Filtro{
	String especialidad; 
	
	public FiltroEspecialidad (String esp) {
		especialidad=esp;
	}

	@Override
	public boolean cumple(Medico m) {
		return m.getEspecialidad().equals(especialidad);
	}
	
	
}

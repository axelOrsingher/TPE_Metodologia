package planteo;

import java.util.Scanner;

public class Menu {
	
	public Menu() {};
	public void iniciarSesion(CentroMedico cm) {
		System.out.println("Ingrese su DNI");
		Scanner entrada = new Scanner (System.in); 
		int dni;
		dni = entrada.nextInt();

		if (!cm.existeDNI(dni)) {
			System.out.println("Ingrese sus datos:");
			System.out.println("DNI:");
			Scanner entrada0 = new Scanner (System.in); 
			long DNI;
			DNI = entrada0.nextLong();
			System.out.println("Nombre: ");
			Scanner entrada1 = new Scanner (System.in); 
			String nombre;
			nombre = entrada1.toString();
			
			System.out.println("Apellido:");
			Scanner entrada2 = new Scanner (System.in); 
			String apellido;
			apellido = entrada2.toString();
			
			System.out.println("Direccion:");
			Scanner entrada3 = new Scanner (System.in); 
			String direccion;
			direccion = entrada3.toString();
			
			System.out.println("Telefono:");
			Scanner entrada4 = new Scanner (System.in); 
			long telefono;
			telefono = entrada4.nextLong();
			
			System.out.println("E-mail:");
			Scanner entrada5 = new Scanner (System.in); 
			String email;
			email = entrada5.toString();
			
			System.out.println("Obra Social:");
			Scanner entrada6 = new Scanner (System.in); 
			String obraSocial;
			obraSocial = entrada6.toString();
			
			System.out.println("Numero de afiliado:");
			Scanner entrada7= new Scanner (System.in); 
			int nroAfiliado;
			nroAfiliado = entrada7.nextInt();
			
			Paciente p = cm.crearCuentaPaciente(DNI, nombre, apellido, direccion, telefono, email, obraSocial, nroAfiliado);
			this.mostrarOpciones(cm,p);
		}
	}
	
	public void mostrarOpciones(CentroMedico cm,Paciente p) {
		System.out.println("Ingrese la opcion que quiera realizar:");
		System.out.println("1.Sacar turno");
		System.out.println("2.Ver turnos venideros");
		System.out.println("3.Cancelar turno");
		System.out.println("4.Cerrar menu");
		Scanner entrada = new Scanner (System.in); 
		int opcion;
		opcion = entrada.nextInt();
		
		
		switch (opcion){
	        case 1:{
	
	        	System.out.println("Ingrese el filtro: ");
				System.out.println("1.Especialidad");
				System.out.println("2.Obra Social");
				System.out.println("3.Ninguno");
				Scanner entrada1 = new Scanner (System.in); 
				int filtro;
				filtro = entrada1.nextInt();

				if (filtro==1) {
					Scanner entrada2 = new Scanner (System.in); 
					String esp;
					System.out.println("Ingrese la especialidad: ");
					esp = entrada2.nextLine();
					
					Filtro f = new FiltroEspecialidad(esp);
					p.sacarTurnoFiltro(cm, f);
				} else if (filtro==2) {
							System.out.println("Ingrese la obra social: ");
							Scanner entrada3 = new Scanner (System.in); 
							String obra;
							obra = entrada3.nextLine();
							
							Filtro f = new FiltroObraSocial(obra);
							p.sacarTurnoFiltro(cm,f);
							}else if (filtro==3) {
								p.sacarTurno(cm);
							}else {System.out.println("Opcion ingresada invalida");}
	
	            break;
		    }
	
	        case 2:{
	
	        	System.out.println("Proximos turnos: ");
				p.verProxTurnos();
	
	            break;
	        }
	
	        case 3:{
	
	        	System.out.println("Ingrese codigo del turno a cancelar: ");
				Scanner entrada23 = new Scanner (System.in); 
				int cod;
				cod = entrada23.nextInt();
				
				if (p.existeTurno(cod)) {
					p.borrarTurno(cod);
				}else {System.out.println("Turno inexistente");}
	            break;
	
	        }
			
			case 4:{
				break;
			}
	
	        default: {
	
	            System.out.println("Opcion incorrecta");
	
	        }
		}
	}}
        
		

		
		
		
		
		
	


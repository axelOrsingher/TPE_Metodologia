package planteo;

import java.time.LocalTime;
import java.util.ArrayList;

public class Medico extends Empleado {
	private String nombre;
    private ArrayList<Turno> turnos;
    private String especialidad;
    private ArrayList<String> obrasSocialesAdheridas;
    private LocalTime horarioInicio;
    private LocalTime horarioFin;
    private Secretaria secretariaAsignada;

    public Medico(String username, String nombre, String password, String especialidad){
        super(username,password);
        this.nombre = nombre;
        this.turnos = new ArrayList<>();
        this.especialidad=especialidad;
        this.obrasSocialesAdheridas = new ArrayList<>();

    }
    
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }



    public LocalTime getHorarioInicio() {
        return horarioInicio;
    }



    public void setHorarioInicio(LocalTime horarioInicio) {
        this.horarioInicio = horarioInicio;
    }



    public LocalTime getHorarioFin() {
        return horarioFin;
    }



    public void setHorarioFin(LocalTime horarioFin) {
        this.horarioFin = horarioFin;
    }



    public Secretaria getSecretariaAsignada() {
        return secretariaAsignada;
    }



    public void setSecretariaAsignada(Secretaria secretariaAsignada) {
        this.secretariaAsignada = secretariaAsignada;
    }



    public String getNombre() {
    	return nombre;
    }
    public ArrayList<String> getObraSocial(){
    	ArrayList<String> aux= new ArrayList<>(obrasSocialesAdheridas);
    	return aux;
    }

    public ArrayList<Turno> getTurnos(){
    	ArrayList<Turno> aux= new ArrayList<>(turnos);
    	return aux;
    }

    public void setSecretaria(Secretaria s){
        secretariaAsignada = s;
    }


	public String getEspecialidad() {
		return especialidad;
	}


	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}


    @Override
    public String toString() {
        return "Medico [especialidad=" + especialidad + ", nombre=" + nombre + "]";
    }


    


}

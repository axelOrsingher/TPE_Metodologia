package planteo;

public abstract class Filtro {
    public abstract boolean cumple(Medico m);
}


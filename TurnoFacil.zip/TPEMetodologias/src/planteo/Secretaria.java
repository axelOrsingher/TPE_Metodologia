package planteo;

import java.util.ArrayList;

public class Secretaria extends Empleado{
    private ArrayList<Medico> medicosAsignados;


    public Secretaria(String username,String password){
        super(username,password);
        medicosAsignados = new ArrayList<>();
    }


    public void agregarMedico(Medico m){
        medicosAsignados.add(m);
    }
    
}
